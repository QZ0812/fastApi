cd ..
tar --exclude=".*" --exclude="*.db" --exclude="*.tar.gz" --exclude="__pycache__" \
-czvf backend_developer_exercise/assignment.tar.gz backend_developer_exercise/