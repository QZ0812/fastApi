from sqlalchemy import *
from sqlalchemy import ForeignKey
from backend.config import settings
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, sessionmaker

engine = create_engine(
    settings.DATABASE_URL, connect_args={"check_same_thread": False}
)

Base = declarative_base()

users_datasets = Table('users_datasets', Base.metadata,
    Column('user_id', Integer, ForeignKey('users.id')),
    Column('dataset_id', Integer, ForeignKey('datasets.id'))
)


class Users(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True)
    name = Column(Text, unique=True, nullable=False)
    surname = Column(Text, nullable=False)
    datasets = relationship("Datasets",
                    secondary=users_datasets,
                    backref="users")


class Datasets(Base):
    __tablename__ = 'datasets'
    id = Column(Integer, primary_key=True)
    name = Column(Text, unique=True, nullable=False)
    description = Column(Text, nullable=False)


Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)
session = Session()