from pydantic import BaseModel


class Dataset(BaseModel):
    id: int
    name: str
    description: str


class DatasetCreate(BaseModel):
    name: str
    description: str


class DatasetUpdate(BaseModel):
    id: int
    name: str
    description: str


class DatasetDelete(BaseModel):
    id: int


class User(BaseModel):
    id: int
    name: str
    surname: str


class UserCreate(BaseModel):
    name: str
    surname: str


class UserDelete(BaseModel):
    id: int


class UserDataset(BaseModel):
    user_id: int
    dataset_id: int