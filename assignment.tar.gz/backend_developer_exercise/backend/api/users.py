from typing import List
from fastapi import APIRouter, status
from backend.models import Users, session, Datasets, users_datasets
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
from backend.schemas import User, UserCreate, UserDataset, UserDelete

users_router = APIRouter()


@users_router.get("/users", response_model=List[User])
def read_users():
    results=session.query(Users).all()
    user_info_list=[each.__dict__ for each in results]

    return user_info_list


@users_router.post("/users", response_model=List[User])
def add_user(user: UserCreate):
    search_by_name_results = session.query(Users).filter(Users.name == user.name).first()
    if search_by_name_results:
        return JSONResponse(status_code=status.HTTP_403_FORBIDDEN,
                            content={"message": "The user name already existed! Please try a new one.",
                                     "status code": 403})
    user_info = Users(**user.dict())
    session.add(user_info)
    session.flush()
    session.commit()
    results = session.query(Users).get(user_info.id)
    return [results.__dict__]


@users_router.delete("/users")
def delete_user(user: UserDelete):
    search_result = session.query(Users).get(user.id)
    if search_result:
        session.delete(search_result)
        session.commit()
        return jsonable_encoder({"message": f"User {search_result.name} is successfully deleted!", "status code": 200})
    return JSONResponse(status_code=status.HTTP_404_NOT_FOUND, content={"message": "The user id you entered doest not exist "
                                                                                 "in database! Bad Request",
                                                                      "status code": 404})


@users_router.post("/give_access")
def give_user_access(user_dataset: UserDataset):
    user_info = session.query(Users).get(user_dataset.user_id)
    dataset_info = session.query(Datasets).get(user_dataset.dataset_id)
    if user_info and dataset_info:
        user_info.datasets.append(dataset_info)
        session.add(user_info)
        session.commit()
        return jsonable_encoder({"message": f"User {user_info.name} is granted the access to dataset {dataset_info.name}", "status code": 200})

    return JSONResponse(status_code=status.HTTP_404_NOT_FOUND,
                        content={"message": "The user id or datase id you entered doest not exist "
                                            "in database! Bad Request",
                                 "status code": 404})


