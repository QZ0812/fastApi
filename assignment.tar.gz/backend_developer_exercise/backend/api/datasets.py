from typing import List
from fastapi import APIRouter, status
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
from backend.models import Datasets, session, users_datasets, Users
from backend.schemas import Dataset, DatasetCreate, DatasetUpdate, DatasetDelete, User


datasets_router = APIRouter()


@datasets_router.get("/datasets", response_model=List[Dataset])
def read_datasets():
    results = session.query(Datasets).all()
    dataset_list = [each.__dict__ for each in results]
    return dataset_list


@datasets_router.post("/datasets", response_model=List[Dataset])
def add_dataset(dataset: DatasetCreate):
    search_by_name_results = session.query(Datasets).filter(Datasets.name == dataset.name).first()
    # if exists, send message to user that try use another name
    if search_by_name_results:
        return JSONResponse(status_code=status.HTTP_403_FORBIDDEN,
                            content={"message": "The dataset name already existed! Please try a new one.",
                                     "status code": 403})
    # if name not exists, insert a new row
    dataset_info = Datasets(**dataset.dict())
    session.add(dataset_info)
    session.flush()
    session.commit()
    results = session.query(Datasets).get(dataset_info.id)
    return [results.__dict__]


@datasets_router.put("/datasets", response_model=List[Dataset])
def update_dataset(dataset: DatasetUpdate):
    # get id, if id already exists, update name and description
    search_by_id_result = session.query(Datasets).get(dataset.id)
    if search_by_id_result:
        search_by_name_result = session.query(Datasets).filter(Datasets.name == dataset.name).first()
        if search_by_name_result and search_by_name_result.id != dataset.id:
            return JSONResponse(status_code=status.HTTP_403_FORBIDDEN,
                                content={"message": "The dataset name already existed! Please try again.", "status code": 403})

        search_by_id_result.name = dataset.name
        search_by_id_result.description = dataset.description
        session.add(search_by_id_result)
        session.commit()
        results = session.query(Datasets).get(dataset.id)
        return [results.__dict__]

    return JSONResponse(status_code=status.HTTP_404_NOT_FOUND,
                        content={"message": "The dataset id you entered doesn't exist! Please create one first.", "status code": 404})


@datasets_router.delete("/datasets")
def delete_dataset(dataset: DatasetDelete):
    search_result = session.query(Datasets).get(dataset.id)
    if search_result:
        session.delete(search_result)
        session.commit()
        return jsonable_encoder({"message": "The dataset is successfully deleted!", "status code": 200})
    return JSONResponse(status_code=status.HTTP_404_NOT_FOUND, content={"message": "The id you entered doest not exist "
                                                                                 "in database! Bad Request",
                                                                      "status code": 404})


@datasets_router.get("/datasets/{dataset_id}", response_model=List[User])
def read_dataset_user(dataset_id: int):
    search_result = session.query(Datasets).get(dataset_id)
    if search_result:
        results = session.query(users_datasets).filter(users_datasets.columns.dataset_id == dataset_id).all()
        user_list = []
        for each in results:
            user_list.append(session.query(Users).get(each.user_id))
        return [each.__dict__ for each in user_list]

    return JSONResponse(status_code=status.HTTP_404_NOT_FOUND, content={"message": "The dataset id you entered doest not exist "
                                                                                   "in database! Bad Request",
                                                                        "status code": 404})