from fastapi.testclient import TestClient

from backend.main import app

client = TestClient(app)


def test_read_users():
    """
    Test the /users GET endpoint.

    :return:
    """
    response = client.get("/users")
    assert response.status_code == 200
    assert len(response.json()) == 0


def test_add_users():
    """
    Test the /users POST endpoint.
    :return:
    """
    response = client.post("/users", json={"name": "Tina", "surname": "Belcher"})
    assert response.status_code == 200
    assert len(response.json()) == 1


def test_add_multiple_users():
    """
    Test that data is stored in the database correctly.

    :return:
    """
    response = client.get("/users")
    assert response.status_code == 200
    assert len(response.json()) == 1

    """
    duplicated name is not allowed.
    """
    response = client.post("/users", json={"name": "Tina", "surname": "Belcher"})
    assert response.status_code == 403

    response = client.get("/users")
    assert response.status_code == 200
    assert len(response.json()) == 1

    response = client.post("/users", json={"name": "Louise", "surname": "Belcher"})
    assert response.status_code == 200

    response = client.get("/users")
    assert response.status_code == 200
    assert len(response.json()) == 2
    print(response.json())


def test_delete_users():
    """
    Test the /users DELETE endpoint.

    :return:
    a message shows that delete succeed and status code 200 if user.id exists
    if id does not find in db, will return 404 not found
    """
    response = client.get("/users")
    assert response.status_code == 200
    assert len(response.json()) == 2

    response = client.delete(
        "/users", json={"id": 1}
    )
    assert response.status_code == 200

    """
    id must be existed to be able to delete.
    """
    response = client.delete(
        "/users", json={"id": 5}
    )
    assert response.status_code == 404

    response = client.get("/users")
    assert response.status_code == 200
    assert len(response.json()) == 1


def test__give_user_access():
    """
    Test the /give_access POST endpoint.

    :return:
    if the input user id and dataset id exist, it will return json string that which user has been granted which dataset.
    if one of input user id or dataset id doesn't valid, it will return warning message.
    """
    response = client.get("/users")
    assert response.status_code == 200
    assert len(response.json()) == 1

    response = client.post(
        "/give_access", json={"user_id": 2, "dataset_id": 2}
    )
    assert response.status_code == 200

    """
    if user_id or dataset_id not found in db, it will return 404
    """
    response = client.post(
        "/give_access", json={"user_id": 1, "dataset_id": 2}
    )
    assert response.status_code == 404