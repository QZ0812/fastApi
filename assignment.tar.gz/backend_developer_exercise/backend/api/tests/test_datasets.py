from fastapi.testclient import TestClient

from backend.main import app

client = TestClient(app)


def test_read_datasets():
    """
    Test the /datasets GET endpoint.

    :return:
    """
    response = client.get("/datasets")
    assert response.status_code == 200
    assert len(response.json()) == 0


def test_add_dataset():
    """
    Test the /datasets POST endpoint.
    :return:
    """
    response = client.post(
        "/datasets", json={"name": "residential", "description": "Residential data."}
    )
    assert response.status_code == 200
    assert len(response.json()) == 1

    """
    duplicated name will not be allowed.
    """
    response = client.post(
        "/datasets", json={"name": "residential", "description": "Residential data-- Duplicated."}
    )
    assert response.status_code == 403


def test_add_multiple_dataset():
    """
    Test that data is stored in the database correctly.

    :return:
    """
    response = client.get("/datasets")
    assert response.status_code == 200
    assert len(response.json()) == 1

    response = client.post(
        "/datasets", json={"name": "goverment", "description": "Government data."}
    )
    assert response.status_code == 200

    response = client.get("/datasets")
    assert response.status_code == 200
    assert len(response.json()) == 2

    response = client.post(
        "/datasets", json={"name": "commercial", "description": "Commercial data."}
    )
    assert response.status_code == 200

    response = client.get("/datasets")
    assert response.status_code == 200
    assert len(response.json()) == 3
    print(response.json())


def test_update_dataset():
    """
    Test the /datasets PUT endpoint.
    :return:
    """

    response = client.get("/datasets")
    assert response.status_code == 200
    assert len(response.json()) == 3

    response = client.put(
        "/datasets", json={"id": 3, "name": "commercial", "description": "Commercial data for Canada."}
    )
    assert response.status_code == 200

    """
    duplicated name will not be allowed.
    """
    response = client.put(
        "/datasets", json={"id": 3, "name": "goverment", "description": "goverment data for Canada."}
    )
    assert response.status_code == 403

    """
    id must be existed to be able to modify.
    """
    response = client.put(
        "/datasets", json={"id": 10, "name": "temp", "description": "temp data."}
    )
    assert response.status_code == 404

    response = client.get("/datasets")
    assert response.status_code == 200
    assert len(response.json()) == 3
    print(response.json())


def test_delete_datasets():
    """
    Test the /datasets DELETE endpoint.

    :return:
    """
    response = client.get("/datasets")
    assert response.status_code == 200
    assert len(response.json()) == 3

    response = client.delete(
        "/datasets", json={"id": 1}
    )
    assert response.status_code == 200

    """
    id must be existed to be able to delete.
    """
    response = client.delete(
        "/datasets", json={"id": 20}
    )
    assert response.status_code == 404

    response = client.get("/datasets")
    assert response.status_code == 200
    assert len(response.json()) == 2
    print(response.json())


def test_read_dataset_user():
    """
    Test the /datasets/{dataset_id} Get endpoint.

    :return:
    it will return all the user lists that have that dataset access
    """
    response = client.get("/datasets")
    assert response.status_code == 200
    assert len(response.json()) == 2

    """
    id must be existed to be able to get
    """
    response = client.get("/datasets/1")
    assert response.status_code == 404

    response = client.get("/datasets/2")
    assert response.status_code == 200



